var factor = {m: 0.6, h: 24, g: 0.22, p: 0.0022}; // setting array for storing conversion constants.

/* Code for length conversion starts here. User enters data and value of user input is collected and checked for numeric entry. Then if the entry is numeric, it is assigned to variable value. Then calculation of conversion is performed and result is displayed. */



function convert1() {
var temp1 = document.getElementById("entry1").value; // geting value of user input and checking correctness.
var value;
if(isNaN(temp1)===false)
{
value = temp1;
var result=value * factor["m"];
document.getElementById("result1").innerHTML= result + " " +  "Miles";
document.getElementById("result1").style.border= "solid"; 
document.getElementById("entry1").style.border="solid blue";
}

/* If the entry is other then numeric, error handling is performed. If the entry is non numeric then it may be null, negative, string or zero. Error handling is performed like that and visibility of the error is made*/

try { 
if (isNaN(temp1)) throw "Number entry required"; // error handling in case the entry is non numeric.
if (temp1 =="") throw "Required field"; // error handling in case the entry is empty.
if(temp1==0)throw "0 not allowed"; // error handling in case the entry is 0.
if(temp1< 0)throw "negetive value  not allowed"; // error handling in case the entry is negative.
}
catch(err) { //creating visibility for error.
document.getElementById("entry1").style.border="5px solid red";
document.getElementById("result1").style.border="5px solid ";
document.getElementById("result1").innerHTML="Error:" + err + ".";
}
}

// Code for length conversion ends here.


/*Code for temperature conversion starts here. User enters data and value of user input is collected and checked for numeric entry. Negative value and zero  is allowed. Then if the entry is numeric (negative / positive) , it is assigned to value. Then calculation of conversion is performed and result is displayed.*/

function convert2() {
var temp2 = document.getElementById("entry2").value;
var value;
if(isNaN(temp2)===false)
{
value = temp2;
var result=32 + value * 9/5;
document.getElementById("result2").innerHTML= result + " " + "Fahrenheit";
document.getElementById("result2").style.border= "solid"; 
document.getElementById("entry2").style.border="solid red";
}
/* If the entry is other then numeric, error handling is performed. If the entry is non numeric then it may be null or string. Error handling is performed like that and visibility of the error is made*/

try {
if (isNaN(temp2)) throw "Number entry required "; // Error handling in case of string entry.
if (temp2 =="") throw "No entry was made"; // Error handling in case of null entry.

}
catch(err) { // creating visibility for error.
document.getElementById("entry2").style.border="5px solid red";
document.getElementById("result2").style.border="5px solid";
document.getElementById("result2").innerHTML="Error:" + err + ".";
}
} //Code for temperature conversion ends here*/

/* Code for time conversion starts here. User enters data and value of user input is collected and checked for numeric entry. Then if the entry is numeric  , it is assigned to value. Then calculation of conversion is performed and result is displayed.*/

function convert3() {
var temp3 = document.getElementById("entry3").value;
var value;
if(isNaN(temp3)===false)
{
value = temp3;
var result=value * factor["h"];
document.getElementById("result3").innerHTML= result + " " + "Hours";
document.getElementById("result3").style.border= "solid"; 
document.getElementById("entry3").style.border="solid cyan";
}

/* If the entry is other then numeric, error handling is performed. If the entry is non numeric then it may be null or string. Or it may be zero or negative. Error handling is performed like that and visibility of the error is made*/

try {
if (isNaN(temp3)) throw "Number entry required"; // Error handling in case of string entry.
if (temp3 =="") throw "No entry was made"; // Error handling in case of null entry.
if(temp3==0)throw "0 not allowed"; // Error handling in case of 0 entry.
if(temp3< 0)throw "negetive value  not allowed"; // Error handling in case of negative value.
}
catch(err) { // Creating visibility of the error.
document.getElementById("entry3").style.border="5px solid red";
document.getElementById("result3").style.border="5px solid";
document.getElementById("result3").innerHTML="Error:" + err + ".";
}
} //Code for time conversion ends here

/*Code for volume conversion strats here. User enters data and value of the entry is checked for whether it is numeric or not. If numeric then it is assigned with a variable value. Then calculation is performed and result is displayed in the result box*/


function convert4() {
var temp4 = document.getElementById("entry4").value;
var value;
if(isNaN(temp4)===false)
{
value = temp4;
var result=value * factor["g"];
document.getElementById("result4").innerHTML= result +  " " + "Gallons";
document.getElementById("result4").style.border= "solid"; 
document.getElementById("entry4").style.border="solid magenta";
}

/* If the entry is other then numeric, error handling is performed. If the entry is non numeric then it may be null or string. Or it may be zero or negative. Error handling is performed like that and visibility of the error is made. */

try { 
if (isNaN(temp4)) throw "Number entry required "; // Error handling in case of string entry.
if (temp4 =="") throw "No entry was made"; // Error handling in case of null entry
if(temp4==0)throw "0 not allowed"; // Error handling in case of 0 entry.
if(temp4< 0)throw "negetive value  not allowed"; // Error handling in case of negative value.
}
catch(err) { // Creating visibility for error.
document.getElementById("entry4").style.border="5px solid red";
document.getElementById("result4").style.border="5px solid";
document.getElementById("result4").innerHTML="Error:" + err + ".";
}
}// Code for volume conversion ends here

/*Code for mass conversion starts here. User enters data and value is checked for correctness. When the value is numeric, it is assigned to variable value and calculation is performed for conversion. Result is displayed in the result box.*/

function convert5() {
var temp5 = document.getElementById("entry5").value;
var value;
if(isNaN(temp5)===false)
{
value = temp5;
var result=value * factor["p"];
document.getElementById("result5").innerHTML= result + " " + "pounds";
document.getElementById("result5").style.border= "solid"; 
document.getElementById("entry5").style.border="solid navy";
}
try {
if (isNaN(temp5)) throw "Number entry required "; // Error handling when entry is string.
if (temp5 =="") throw "No entry was made"; // Error handling when entry is null.
if(temp5==0) throw "0 not allowed"; // Error handling when entry is 0.
if(temp5< 0) throw "negetive value  not allowed"; // Error when entry is negative.
}
catch(err) { // Creating visibility for error.
document.getElementById("entry5").style.border="5px solid red";
document.getElementById("result5").style.border="5px solid";
document.getElementById("result5").innerHTML="Error:" + err + ".";
}


} //Code for mass conversion ends here

/* Code for opening help pop up window*/

function showHelp1() {
alert("Data used : 1 Km = 0.6 Mile ");
}

function showHelp3() {
alert("Data used : 1 day = 24 hrs ");
}

function showHelp2() {
alert("Formula used : Fahrenheit = 32 + (celsius * 9/5) ");
}

function showHelp4() {
alert("Data used : 1 liter  = 0.22 gallon ");
}
function showHelp5() {
alert("Data used : 1 gm = 0.0022 pounds ");
}




