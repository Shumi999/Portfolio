﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Virada_games_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /* *****************************************************************************
         * Code section 1: Class declaration for Item types, Customer and Transection. 
         ******************************************************************************* */
        
     
       /* 1.1: Parent Class declaration for Item*/
       
        class Item
        {
            public string itemID;
            public string desc;
            public string sqty;
            public string cost;

            public string itemID1;
            public string desc1;
            public string sqty1;
            public string cost1;

            public string gsID
            {
                get { return itemID; }
                set { itemID1 = value; }
            }

            public string gsDesc
            {
                get { return desc; }
                set { desc1 = value; }
            }

            public string gsSQty
            {
                get { return sqty; }
                set { sqty1 = value; }
            }

            public string gsCost
            {
                get { return cost; }
                set { cost1 = value; }
            }
        } // end Item

        /* 1.1.1: Subclass declaration for subclass Game*/

        class Game : Item
        {
            public string publisher;
            public string MType;

            public string publisher1;
            public string MType1;

            public Game()
            {
            }

            public Game(string itemID1, string desc1, string sqty1, string cost1, string publisher1, string MType1)
            {
                itemID1 = itemID;
                desc1 = desc;
                sqty1 = sqty;
                cost1 = cost;
                publisher1 = publisher;
                MType1 = MType;
            }


            public string gsPub
            {
                get { return publisher; }
                set { publisher1 = value; }
            }

            public string gsMType
            {
                get { return MType; }
                set { MType1 = value; }
            }

        } // end Game

      /*      1.1.2: Subclass declaration for Platform*/

        class Platform : Item
        {

            public string mNum;
            public string mNum1;

            public Platform()
            {
            }

            public Platform(string itemID1, string desc1, string sqty1, string cost1, string mNum1)
            {
                itemID1 = itemID;
                desc1 = desc;
                sqty1 = sqty;
                cost1 = cost;
                mNum = mNum1;
            }

            public string gsMNum
            {
                get { return mNum; }
                set { mNum1 = value; }
            }
        } // end platform

          /*1.1.3: Subclass declaration for Accessories
         */
        class Accessories : Item
        {

            public string pType;
            public string pType1;

            public Accessories()
            {
            }

            public Accessories(string itemID1, string desc1, string sqty1, string cost1, string pType1)
            {

                itemID1 = itemID;
                desc1 = desc;
                sqty1 = sqty;
                cost1 = cost;
                pType1 = pType;
            }


            public string gsPType
            {
                get { return pType; }
                set { pType1 = value; }
            }

        }// end Accessories

       /* 1.2 : Class declaration for customer*/
        class Customer
        {
            public string custID;
            public string fName;
            public string lName;
            public string eMail;

            public Customer(string custID1, string fName1, string lName1, string eMail1)
            {
                custID = custID1;
                lName = lName1;
                fName = fName1;
                eMail = eMail1;

            }

            public Customer()
            {
            }

} // end of Customer

        /*1.3: Class declaration for Transection*/

        class Transection
        {
            
            public string custID;
            public string itemID;
            public string qty;
            public string cost;
            public string date;

            public Transection(string custID1, string itemID1, string qty1, string cost1, string date1)
            {
               
                custID = custID1;
                itemID = itemID1;
                qty = qty1;

                cost = cost1;
               date = date1;

            }

            public Transection()
            {
            }

        }
            // end of transection

           /************************
            * End class declaration. 
            * **********************/
        List<Customer> customer = new List<Customer>();
        List<Transection> transection = new List<Transection>();
        List<Item> item = new List<Item>();

        /******************************
         *Section 2:  Form load event reads previously saved data from corresponding binery file
         * *****************************/

        private void Form1_Load(object sender, EventArgs e)
        {
            //data is retrieved from the binery file Item.dat and gets stored in the list collection 'item'.
            //Each odf the items from list gets displayed in the corresponding listbox.

            /* 2.1: Data retrieval for Item starts here*/
             string newline = "";
            listBox3.Items.Clear();

            BinaryReader br1;
              br1 = new BinaryReader(new FileStream("Item.dat", FileMode.Open));
              while (true)
              {

                  try
                  {

                      Game aGame = new Game();


                      aGame.itemID = br1.ReadString();
                      aGame.desc = br1.ReadString();

                      aGame.sqty = br1.ReadString();
                      aGame.cost = br1.ReadString();
                      aGame.publisher = br1.ReadString();
                      aGame.MType = br1.ReadString();
                      item.Add(aGame);
                      newline = aGame.itemID + " , " + aGame.desc;
                      listBox3.Items.Add(newline);

                      Platform aPlatform = new Platform();
                      aPlatform.itemID = br1.ReadString(); ;
                      aPlatform.desc = br1.ReadString(); ;
                      aPlatform.cost = br1.ReadString(); ;
                      aPlatform.sqty = br1.ReadString(); ;
                      aPlatform.cost = br1.ReadString(); ;
                      aPlatform.mNum = br1.ReadString(); ;
                      item.Add(aPlatform);
                      newline = aPlatform.itemID + " , " + aPlatform.desc;
                      listBox3.Items.Add(newline);

                      Accessories aAccessories = new Accessories();
                      aAccessories.itemID = br1.ReadString();
                      aAccessories.desc = br1.ReadString();
                      aAccessories.cost = br1.ReadString();
                      aAccessories.sqty = br1.ReadString();
                      aAccessories.cost = br1.ReadString();
                      aAccessories.pType = br1.ReadString();
                      item.Add(aAccessories);
                      newline = aAccessories.itemID + " , " + aAccessories.desc;
                      listBox3.Items.Add(newline);

                  }
                  catch (Exception) { break; }

              }

              /* 2.2: Data retrieval for customer starts here*/

              listBox1.Items.Clear();

              BinaryReader br2;

              br2 = new BinaryReader(new FileStream("Customer.dat", FileMode.Open));


              while (true) // for allowing data retrieval till the program is running.
              {
                  //reading customer object fields from file

                  try
                  {
                      Customer aCustomer = new Customer();
                      aCustomer.custID = br2.ReadString();
                      aCustomer.fName = br2.ReadString();
                      aCustomer.lName = br2.ReadString();
                      aCustomer.eMail = br2.ReadString();

                      newline = aCustomer.custID + "  " + aCustomer.fName + " " + aCustomer.lName;

                      customer.Add(aCustomer);

                      listBox1.Items.Add(newline);
                  }
                  catch (Exception) // catches the EOF
                  {
                      break;
                  }


              } // end while 

              // 2.3: Data retrieval for transection starts here//

              listBox2.Items.Clear();

              BinaryReader br3;

              br3 = new BinaryReader(new FileStream("Transection.dat", FileMode.Open));


              while (true) // for allowing data retrieval till the program is running.
              {
                  //reading contact object fields from file

                  try
                  {
                      Transection aTransection = new Transection();
                      aTransection.custID = br3.ReadString();
                      aTransection.itemID = br3.ReadString();
                      aTransection.qty = br3.ReadString();
                      aTransection.cost = br3.ReadString();
                      aTransection.date = br3.ReadString();
                      newline = aTransection.custID + "  " + aTransection.itemID + "  " + aTransection.qty + " " + aTransection.cost + "  " + aTransection.date;

                      transection.Add(aTransection);

                      listBox2.Items.Add(newline);
                  }
                  catch (Exception) // catches the EOF
                  {
                      break;
                  }


              } // end while 

              br1.Close();
              br2.Close(); // closing br2 reader for further operation on the binery file.
              br3.Close(); // closing br2 reader for further operation on the binery file.
        } // end of form load and data retrieval



        /***********************************************************
               * Code section 3: Getting data from the user interface at runtime, 
               * storing data in corresponding list collections 
               * Displaying data in the listbox
               * and saving into the corresponding binery file 
               * **********************************************************/

        // 3.1 Getting Item data from the user form

        private void itemAdd_Click(object sender, EventArgs e)
        {
            string itemID = textBox10.Text;
            string desc = textBox11.Text;
            string sqty = textBox12.Text;
            string cost = textBox13.Text;
            string publisher = textBox14.Text;
            string MType = textBox15.Text;
            string mNum = textBox16.Text;
            string pType = textBox17.Text;
            if (textBox10.Text != "" && textBox11.Text != "" && textBox12.Text != "" && textBox13.Text != "" && textBox14.Text != "" && textBox15.Text != "" && textBox16.Text == "" && textBox17.Text == "")
            {
                Game aGame = new Game(itemID, desc, sqty, cost, publisher, MType);
                aGame.itemID = textBox10.Text;
                aGame.desc = textBox11.Text;
                aGame.sqty = textBox12.Text;
                aGame.cost = textBox13.Text;
                aGame.publisher = textBox14.Text;
                aGame.MType = textBox15.Text;
                item.Add(aGame);
                listBox3.Items.Add(aGame.itemID + " " + aGame.desc);
                tbClear1();
            }

            else if (textBox10.Text != "" && textBox11.Text != "" && textBox12.Text != "" && textBox13.Text != "" && textBox14.Text == "" && textBox15.Text == "" && textBox16.Text != "" && textBox17.Text == "")
            {
                Platform aPlatform = new Platform(itemID, desc, sqty, cost, mNum);
                aPlatform.itemID = textBox10.Text;
                aPlatform.desc = textBox11.Text;
                aPlatform.sqty = textBox12.Text;
                aPlatform.cost = textBox13.Text;

                aPlatform.mNum = textBox16.Text;
                item.Add(aPlatform);
                listBox3.Items.Add(aPlatform.itemID + " " + aPlatform.desc);
                tbClear1();
            }

            else if (textBox10.Text != "" && textBox11.Text != "" && textBox12.Text != "" && textBox13.Text != "" && textBox14.Text == "" && textBox15.Text == "" && textBox16.Text == "" && textBox17.Text != "")
            {
                Accessories aAccessories = new Accessories(itemID, desc, sqty, cost, pType);
                aAccessories.itemID = textBox10.Text;
                aAccessories.desc = textBox11.Text;
                aAccessories.sqty = textBox12.Text;
                aAccessories.cost = textBox13.Text;
                aAccessories.pType = textBox17.Text;
                item.Add(aAccessories);
                listBox3.Items.Add(aAccessories.itemID + " " + aAccessories.desc);
                tbClear1();
            }

            else
            {
                MessageBox.Show("Please check entry under proper headimng");

            }

            // Writing data to Binery file.
            BinaryWriter bw3;
            bw3 = new BinaryWriter(new FileStream("Item.dat", FileMode.Create));



            // iterating through list  and writing objects to the file

            try
            {

                for (int i = 0; i < item.Count; i++)
                {
                    if (item[i] is Game)
                    {
                        Game tGame = (Game)item[i];
                        bw3.Write(tGame.itemID);
                        bw3.Write(tGame.desc);
                        bw3.Write(tGame.sqty);
                        bw3.Write(tGame.cost);
                        bw3.Write(tGame.publisher);
                        bw3.Write(tGame.MType);


                    }

                    if (item[i] is Platform)
                    {
                        Platform tPlatform = (Platform)item[i];
                        bw3.Write(tPlatform.itemID);
                        bw3.Write(tPlatform.desc);
                        bw3.Write(tPlatform.sqty);
                        bw3.Write(tPlatform.cost);

                        bw3.Write(tPlatform.mNum);

                    }

                    if (item[i] is Accessories)
                    {
                        Accessories tAccessories = (Accessories)item[i];
                        bw3.Write(tAccessories.itemID);
                        bw3.Write(tAccessories.desc);
                        bw3.Write(tAccessories.sqty);
                        bw3.Write(tAccessories.cost);

                        bw3.Write(tAccessories.pType);
                    }
                } // end loop
            }
            catch (Exception) { }

            bw3.Close();

        }//end of data entry of item

        //3.2: Data entry for customer section//

        private void btnCustAdd_Click(object sender, EventArgs e)
        {
            string custID = textBox1.Text; ;
            string fName = textBox2.Text;
            string lName = textBox3.Text;
            string eMail = textBox4.Text;

            // create customer object from data on the form
            Customer aCustomer = new Customer(custID, fName, lName, eMail);
            //add to collection
            customer.Add(aCustomer);
            //add to listbox
            listBox1.Items.Add(aCustomer.custID + " , " + aCustomer.fName + " , " + aCustomer.lName + " ,  " + aCustomer.eMail);
            tbClear2();

            // writing to the binery file starts here

            BinaryWriter bw1;
            bw1 = new BinaryWriter(new FileStream("Customer.dat", FileMode.Create));


            // iterating through list  and writing objects to the file
            foreach (Customer itemCustomer in customer)
            {
                //writing customer object fields to file


                bw1.Write(itemCustomer.custID);
                bw1.Write(itemCustomer.fName);
                bw1.Write(itemCustomer.lName);
                bw1.Write(itemCustomer.eMail);

            }

            bw1.Close();


        } // end of data entry for customer     

        // 3.3: Data entry for transection //

        private void btnTranAdd_Click(object sender, EventArgs e)
        {
            string custID = textBox5.Text;
            string itemID = textBox6.Text;
            string qty = textBox7.Text;
            string cost = textBox8.Text;
            string date = textBox9.Text;


            //create transection  object from data on the form
            Transection aTransection = new Transection(custID, itemID, qty, cost, date);
            //add to collection

            transection.Add(aTransection);
            //add to listbox
            listBox2.Items.Add(aTransection.custID + "  " + aTransection.itemID + "  " + aTransection.qty + "  " + aTransection.cost + "  " + aTransection.date);
            tbClear3();

            //create the transection.dat and writing to the file
            BinaryWriter bw2;
            bw2 = new BinaryWriter(new FileStream("Transection.dat", FileMode.Create));


            // iterating through list  and writing objects to the file
            foreach (Transection itemTransection in transection)
            {
                //writing transection objects fields to file



                bw2.Write(itemTransection.custID);
                bw2.Write(itemTransection.itemID);
                bw2.Write(itemTransection.qty);
                bw2.Write(itemTransection.cost);
                bw2.Write(itemTransection.date);


            }

            bw2.Close();

        } // data entry and writing in binery file for transction ends here
        /*******************************************************************
         * Section 4: Code for serach starts here.
         * ******************************************************************/

        // 3.1: Search for item in the item section //

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string curItem3 = listBox3.SelectedItem.ToString();


            // Retrieving the 'custID' part of the selected item.

            string[] substring = curItem3.Split();
            string fitemID = substring[0];

            // Finding the found 'itemID' relevent object in the item list

            int index = item.FindIndex(x => x.itemID == fitemID);
            try
            {

                if (item[index] is Game)
                {
                    Game tGame = (Game)item[index];
                    textBox10.Text = tGame.itemID;
                    textBox11.Text = tGame.desc;
                    textBox12.Text = tGame.sqty;
                    textBox13.Text = tGame.cost;
                    textBox14.Text = tGame.publisher;
                    textBox15.Text = tGame.MType;
                    textBox16.Text = "";
                    textBox17.Text = "";
                }
                if (item[index] is Platform)
                {
                    Platform tPlatform = (Platform)item[index];
                    textBox10.Text = tPlatform.itemID;
                    textBox11.Text = tPlatform.desc;
                    textBox12.Text = tPlatform.sqty;
                    textBox13.Text = tPlatform.cost;
                    textBox14.Text = "";
                    textBox15.Text = "";
                    textBox16.Text = tPlatform.mNum;
                    textBox17.Text = "";

                }

                if (item[index] is Accessories)
                {
                    Accessories tAccessories = (Accessories)item[index];
                    textBox10.Text = tAccessories.itemID;
                    textBox11.Text = tAccessories.desc;
                    textBox12.Text = tAccessories.sqty;
                    textBox13.Text = tAccessories.cost;
                    textBox14.Text = "";
                    textBox15.Text = "";
                    textBox16.Text = "";
                    textBox17.Text = tAccessories.pType;


                }
            }

            catch (Exception) { }

            // Finding the found 'itemID' relevent object in the transection list

            try
            {
                Transection tempTran = transection.Find(aTransection => aTransection.itemID.Contains(fitemID));
                textBox5.Text = tempTran.custID;
                textBox6.Text = tempTran.itemID;
                textBox7.Text = tempTran.qty;
                textBox8.Text = tempTran.cost;
                textBox9.Text = tempTran.date;
            }
            catch (Exception) { }

        } // end of list box 3

        // 4.2: Search for customer in the customer section //

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Retrieving the selected item in the listbox.

            string curItem = listBox1.SelectedItem.ToString();

            // Retrieving the 'custID' part of the selected item.

            string[] substring = curItem.Split();
            string fCustID = substring[0];

            // Finding the found 'custID' relevent customer object in the list
            Customer tCust = customer.Find(aCustomer => aCustomer.custID.Contains(fCustID));
            Transection tTransection = transection.Find(aTransection => aTransection.custID.Contains(fCustID));


            //Displaying parameters of the found customer objects in the apropriate text boxes in the form.

            textBox1.Text = tCust.custID;
            textBox2.Text = tCust.fName;
            textBox3.Text = tCust.lName;
            textBox4.Text = tCust.eMail;

            textBox5.Text = tTransection.custID;
            textBox6.Text = tTransection.itemID;
            textBox8.Text = tTransection.cost;
            textBox7.Text = tTransection.qty;
            textBox9.Text = tTransection.date;



        } // list box 1 code ends here


        // 4.3: Search for transection in the Transection section //

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Retrieving the selected item in the listbox.

            string curItem2 = listBox2.SelectedItem.ToString();

            // Retrieving the 'custID' part of the selected item.

            string[] substring2 = curItem2.Split(' ');

            string tCustID = substring2[0];
            string tItemID = substring2[2];

            // Finding the found 'tcustID' relevent customer object in the list
            Transection Tran = transection.Find(aTransection => aTransection.custID.Contains(tCustID));
            Customer tempCust = customer.Find(aCustomer => aCustomer.custID.Contains(tCustID));

            textBox5.Text = Tran.custID;
            textBox6.Text = Tran.itemID;
            textBox7.Text = Tran.qty;
            textBox8.Text = Tran.cost;
            textBox9.Text = Tran.date;

            textBox1.Text = tempCust.custID;
            textBox2.Text = tempCust.fName;
            textBox3.Text = tempCust.lName;
            textBox4.Text = tempCust.eMail;

            //Finding tItemID relevent item object in the item list and displaying data

            int index = item.FindIndex(x => x.itemID == tItemID);
            try
            {
                if (item[index] is Game)
                {
                    Game tGame = (Game)item[index];
                    textBox10.Text = tGame.itemID;
                    textBox11.Text = tGame.desc;
                    textBox12.Text = tGame.sqty;
                    textBox13.Text = tGame.cost;
                    textBox14.Text = tGame.publisher;
                    textBox15.Text = tGame.MType;
                    textBox16.Text = "";
                    textBox17.Text = "";
                }
                if (item[index] is Platform)
                {
                    Platform tPlatform = (Platform)item[index];
                    textBox10.Text = tPlatform.itemID;
                    textBox11.Text = tPlatform.desc;
                    textBox12.Text = tPlatform.sqty;
                    textBox13.Text = tPlatform.cost;
                    textBox14.Text = "";
                    textBox15.Text = "";
                    textBox16.Text = tPlatform.mNum;
                    textBox17.Text = "";

                }

                if (item[index] is Accessories)
                {
                    Accessories tAccessories = (Accessories)item[index];
                    textBox10.Text = tAccessories.itemID;
                    textBox11.Text = tAccessories.desc;
                    textBox12.Text = tAccessories.sqty;
                    textBox13.Text = tAccessories.cost;
                    textBox14.Text = "";
                    textBox15.Text = "";
                    textBox16.Text = "";
                    textBox17.Text = tAccessories.pType;


                }
            }

            catch (Exception) { }

        } // code for list box 2 ends here

        /***********************
         * Section 5: Code for clearing the 
         * text boxes for next data entry
         * **********************/
        public void tbClear1()
        {
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
            textBox13.Text = "";
            textBox14.Text = "";
            textBox15.Text = "";
            textBox16.Text = "";
            textBox17.Text = "";
        } // method clear to use with Item

        public void tbClear2()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";

        } // method clear to use with customer

        public void tbClear3()
        {
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }// end clear to use with transection

    }
} 
       
           

                  


                   


                    


                   
               

                
           


          



           


        

       

       

      

       

       


        

       


        

       

       

       
                   
        

        

       

       
       
       

        

   

        
        
    