/*
 *This program is to record Bird watch.
 *@author: Moushumi Ahmed.
 *ID: 542646
 *version: 1.0
 */
 
/**
 *Purpose of the class is to display data for every birdsighting event.
 */

public class TestBirdSighting
{
/**
 *The main method collects and assigns data
 *for displaying, from BirdSighting class.
 */
    public static void main(String[] args){
        BirdSighting BirdWatch = new BirdSighting();
        BirdWatch.displayData(); /* Default values in use.*/


        String newSpecies = BirdSighting.getSpecies();
        int newNum = BirdSighting.getNum();
        int newDay= BirdSighting.getDay();
        BirdWatch.displayData(); /*Obtained values in use*/
} // end main
}//end class