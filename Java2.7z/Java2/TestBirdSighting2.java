
/**
 *This program keeps record of incidents of bird watch.
 *@author: Moushumi Ahmed.
 *ID: 542646
 *version: 1.0
 */

public class TestBirdSighting2 {

/**
 *The main method displays bird watch data.
 */
    public static void main(String[] args){

        

        BirdSighting2 BirdWatch = new BirdSighting2(); 
        BirdWatch.displayData(); // statement shows default values.
        
        
        String newSpecies = BirdSighting2.getSpecies();
        int newNum = BirdSighting2.getNum();
        int newDay= BirdSighting2.getDay();
        BirdWatch.displayData(); // statement showing input data.
        }//end main
}//end class