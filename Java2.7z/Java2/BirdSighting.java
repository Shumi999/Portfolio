import java.util.*;

/*
 *This program is to record Birds watched..
 *@author: Moushumi Ahmed.
 *ID: 542646
 *version: 1.0
 */
 
/**
 *Purpose of the class is to get data for every birdsighting event.
 */
public class BirdSighting {
    static String Species, newSpecies;
    static int Num,Day,year, month, dayOfMonth, newNum,newDay ;
    

//constructor BirdSighting.

/* Two following constructors define the BirdSighting event.*/
/**
 *This default constructor sets a default value for the data fields
 */ 

public BirdSighting(){
    Species = "Robin";
    Day = 1;
    Num = 1;
    }

/**
 *This default constructor assigns value for the data fields
 */ 
 
public BirdSighting(String newSpecies, int newNum, int newDay){
    Species = newSpecies;
    Day = newDay;
    Num = newNum;
    }

/**
 * This method collects name of the bird.
 */
 

    public static String getSpecies() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Which bird have you wached?");
        Species = keyboard.next();

        return Species;
        }
/**
 * This method collects quantity seen.
 */
    public static int getNum(){
        Scanner keyboard = new Scanner(System.in);
        System.out.println("How many of the bird was observed?");
        Num = keyboard.nextInt();
        return Num;
        }

/**
 * This method collects the day of the year the bird was seen.
 */
 
    public static int getDay(){
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Please enter the date of watching (DD/MM/YYYY):");
        System.out.println("DD:");
        dayOfMonth = keyboard.nextInt();
        System.out.println("MM:");
        int TempMonth = keyboard.nextInt();
        month = (TempMonth - 1);
        System.out.println("YYYY:");
        year = keyboard.nextInt();


        GregorianCalendar Date = new GregorianCalendar(year, month, dayOfMonth); /* demonstrates use of Gregorian calender*/


        Day = Date.get(GregorianCalendar.DAY_OF_YEAR);
        return Day;
        }

/**
 * This method shows data for the birdwatch event.
 */

    public static void displayData(){

        System.out.println("Bird watched:" + Species);
        System.out.println("Number of the bird watched:" + Num);
        System.out.println("Day of the year the bird was seen:" + Day);
        }
}//end class


