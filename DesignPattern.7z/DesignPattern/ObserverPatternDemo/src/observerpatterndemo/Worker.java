
package observerpatterndemo;

/*
 * Purpose of this class is to  act as the abstract supertype of the dependant classes in one to many relationship.
 * Reference: https://www.tutorialspoint.com/design_pattern/observer_pattern.htm
 */
public abstract class Worker {
    
    protected Subject subject;
    protected int wage;
    public abstract void inform(int wage); // declares abstract method to notify dependant classes of any change.
}
