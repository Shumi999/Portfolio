
package observerpatterndemo;

/**
 * This class extends the superclass and implements polymorphism.
 * Reference: https://www.tutorialspoint.com/design_pattern/observer_pattern.htm
 */
 
public class WorkerTwo extends Worker{
    
     public WorkerTwo (Subject subject){
        this.subject = subject;
        this.subject.add(this);
    }
     
     
    /*
     * Following method overrides the abstract method of the superclass
     * and implements polymorphism 
     * This method reflects the change in class specific way.
     */
     
     
     @Override
    public void inform(int wage){
        int curWage = 3000;
          int newWage = curWage + wage;
       
        System.out.println("For WorkerTwo: " + " "+ "Pay rise:" + " " + wage + " New pay: " + newWage);
        
    }
}
