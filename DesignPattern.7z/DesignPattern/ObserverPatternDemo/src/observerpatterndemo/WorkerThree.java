/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerpatterndemo;

 /* This class extends the superclass and implements polymorphism.
  * Reference: https://www.tutorialspoint.com/design_pattern/observer_pattern.htm
  */


public class WorkerThree extends Worker {
     public WorkerThree (Subject subject){
        this.subject = subject;
        this.subject.add(this);
    }
        
        
    /*
     * Following method overrides the abstract method of the superclass
     * and implements polymorphism 
     * This method reflects the change in class specific way.
     */
     
    @Override
    public void inform(int wage){
        int curWage = 3500;
         int newWage = curWage + wage;
    
        System.out.println("For WorkerThree: " + " "+ "Pay rise:" + " " + wage + " New pay: " + newWage);
    }
}
