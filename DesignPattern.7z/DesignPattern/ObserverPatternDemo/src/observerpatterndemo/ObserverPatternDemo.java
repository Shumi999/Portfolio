
package observerpatterndemo;

/* 
 * Purpose : Purpose of the program is to demonstrate use of Observer design pattern.
 * Code reference: https://www.tutorialspoint.com/design_pattern/observer_pattern.htm
 */

public class ObserverPatternDemo {

    
    public static void main(String[] args) {
     Subject subject =new Subject();
     
     /* Following code block instantiate object for three subclass type
      * which receives copy of the subject object
      * And then use subject to attach it to an ArrayList,
      * Reflect new change to all the object type
      * Displays outcome.
     */
     new WorkerOne(subject); // instance of the dependant classes use the subject class 
     new WorkerTwo(subject);
     new WorkerThree(subject);
     
     
     System.out.println("Pay will rise $100");
     subject.setWage(100);
     System.out.println();
     System.out.println("Pay will rise $200");
     subject.setWage(200);
    }
} // end class 
    

