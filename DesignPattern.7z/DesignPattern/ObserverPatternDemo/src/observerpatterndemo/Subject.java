


package observerpatterndemo;

/*
 * Purpose of this class is to  act as the Subject
 * To attache a new instance of the dependand subclass (which is one of the many classes dependant on the 
 * Superclass), 
 * To infor all the dependant subclaees about new change,
 * and display outcome specific to the object type, implementing encapsulation and polymorphism.
 * Reference: https://www.tutorialspoint.com/design_pattern/observer_pattern.htm
 */

import java.util.ArrayList;
import java.util.List;



public class Subject {
    
    private List<Worker> workers = new ArrayList<Worker>();
   private int wage;
   
   public int getWage(){
       
       return wage;
   }
    
   public void setWage(int wage){ // sets information to all the subclasses in one to many relationship.
       this.wage = wage;
       notifyWorkers(wage);
   }
   
   public void add(Worker worker){ // adding subclass instances
       workers.add(worker);
   }
   
   
    
   public void notifyWorkers(int wage){ // method to notify all the dependant classes.
       
       for(Worker worker: workers){
           worker.inform(wage);
       }
   }
}
